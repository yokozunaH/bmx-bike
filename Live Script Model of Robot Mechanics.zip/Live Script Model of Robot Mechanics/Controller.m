function [tau_d,e_total,e_prev] = Controller(state,eint,prevError)

params = init_params;
Kp = 5;
Ki = .1;
Kd = 1;

set = pi/2-params.model.geom.bw_com.theta;
eintmax = 3000;

error = set-state;


if (eint>eintmax)
    eint = eintmax;
elseif (eint<-eintmax)
    eint = -eintmax;
end

tau_d = Kp * error + Ki * eint + Kd *(error-prevError);
e_total = eint+error;
e_prev = error;

end
